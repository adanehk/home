
package com.mycompany.adanelhninielkarti;


public class Balda {
    private String tema;
    Libro[] libro;
    int numLibros;
    
    
public Balda(String tema,int numLibros){
    this.tema=tema;
    libro = new Libro[numLibros];
    this.numLibros=0;
    this.numLibros=numLibros;
}

public void agregarLibro(Libro libro){
    if(numLibros<this.libro.length){
        this.libro[numLibros++]=libro;
    }
}

//COMENTADO PORQUE HACE QUE EL MAIN CASQUE Y NO VEO DONDE ESTA EL ERROR
//public int contarLibrosGrandes(int numPaginas){
//    int num = 0;
//    for(int i=0;i<libro.length;i++){
  //      if(libro[i].getPaginas()>numPaginas){
    //        num++;
      //  }
    //}
    //return num;
//}
}
